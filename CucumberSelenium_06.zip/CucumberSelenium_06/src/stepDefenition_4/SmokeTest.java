package stepDefenition_4;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SmokeTest {
	WebDriver driver;
	JavascriptExecutor js;

	@Given("^open chrome and start application$")
	public void open_chrome_and_start_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
		js = (JavascriptExecutor) driver;
		driver.manage().window().maximize();
		driver.get("https://github.com/login");

	}

	@When("I enter valid username and valid password")
	public void i_enter_valid_username_and_valid_password() {
		driver.findElement(By.id("login_field")).sendKeys("elsasianturi2020@gmail.com");
	    driver.findElement(By.id("password")).sendKeys("antioil");
	}
	
	@Then("I can login successfully")
	public void i_can_login_successfully() {
		driver.findElement(By.name("commit")).click();
	}
	
	@Then("I click profile")
	public void i_click_profile() throws InterruptedException {
	    driver.findElement(By.xpath("/html/body/div[1]/header/div[7]/details")).click();
		Thread.sleep(1000);
	}
	
	@Then("I click create$")
	public void i_click_create() {
		js.executeScript("document.querySelector(\"#mount_0_0_Tc > div > div > div.x9f619.x1n2onr6.x1ja2u2z > div > div > div > div.x78zum5.xdt5ytf.x10cihs4.x1t2pt76.x1n2onr6.x1ja2u2z > div.x9f619.xnz67gz.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.xdt5ytf.xqjyukv.x1qjc9v5.x1oa3qoh.x1qughib > div.x9f619.xjbqb8w.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.xdt5ytf.xqjyukv.x1qjc9v5.x1oa3qoh.x1nhvcw1.xixxii4.xg7h5cd.xh8yej3.x1vjfegm.x1ey2m1c.x80663w.x1jeouym.x6w1myc > div > div > div > div > div:nth-child(4) > div > div > a > div > div > div > div\")");
	}
	
	@Then("I click select from computer")
	public void i_click_select_from_computer() {
		driver.findElement(By.xpath("//*[@id=\"mount_0_0_Tc\"]/div/div/div[3]/div/div/div[1]/div/div[3]/div/div/div/div/div[2]/div/div/div/div[2]/div[1]/div/div/div[2]/div/button")).click();
	}
	

}
