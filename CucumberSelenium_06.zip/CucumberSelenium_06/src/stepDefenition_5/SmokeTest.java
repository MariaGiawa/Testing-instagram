package stepDefenition_5;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SmokeTest {
	WebDriver driver;
	JavascriptExecutor js;
	
	@Given("open chrome and start application")
	public void open_chrome_and_start_application() {
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		
		driver = new ChromeDriver();
		js = (JavascriptExecutor) driver;
		driver.manage().window().maximize();
		driver.get("https://github.com/login");
	}
	
	@When("I enter valid username and valid password")
	public void i_enter_valid_username_and_valid_password() {
		driver.findElement(By.id("login_field")).sendKeys("elsasianturi2020@gmail.com");
	    driver.findElement(By.id("password")).sendKeys("antioil");
	}
	@Then("I can login successfully")
	public void i_can_login_successfully() {
		driver.findElement(By.name("commit")).click();
	}
	
	@Then("I click dropdown menu")
	public void i_click_dropdown_menu() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"mount_0_0_Tc\"]/div/div/div[2]/div/div/div/div[1]/div[1]/div[1]/div/div/div/div/div[3]/div/a/div/div[1]/div/div")).click();
		Thread.sleep(1000);
	}
	
	@Then("I choose setting")
	public void i_choose_setting() {
		js.executeScript("document.querySelector(\"#mount_0_0_Tc > div > div > div.x9f619.x1n2onr6.x1ja2u2z > div > div > div > div:nth-child(2) > div > div > div.xu96u03.xm80bdy.x10l6tqk.x13vifvy > div.x1uvtmcs.x4k7w5x.x1h91t0o.x1beo9mf.xaigb6o.x12ejxvf.x3igimt.xarpa2k.xedcshv.x1lytzrv.x1t2pt76.x7ja8zs.x1n2onr6.x1qrby5j.x1jfb8zj > div > div > div > div.xgf5ljw.x78zum5.xdt5ytf.x5yr21d.x1n2onr6.xh8yej3.x13b9bq5.x6ikm8r.x10wlt62.xfh8nwu.xoqspk4.x12v9rci.x138vmkv > div > div > div.x9f619.x1ja2u2z.x1k90msu.x6o7n8i.x1qfuztq.x10l6tqk.x17qophe.x13vifvy.x1hc1fzr.x71s49j.xh8yej3 > div > a:nth-child(1) > div.x9f619.xjbqb8w.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1pi30zi.x1swvt13.x1l90r2v.xyamay9.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.xdt5ytf.xqjyukv.x1qjc9v5.x1oa3qoh.x1nhvcw1\")");
	}
	
	@Then("I click text box")
	public void i_click_text_box() {
		driver.findElement(By.xpath("//*[@id=\"mount_0_0_Tc\"]/div/div/div[2]/div/div/div/div[1]/div[1]/div[2]/section/main/div/article/form/div[2]")).sendKeys("Born To Die");
	}
	
		
	@Then("I click button submit")
	public void i_button_click_submit() {
		driver.findElement(By.xpath("//*[@id=\"mount_0_0_Tc\"]/div/div/div[2]/div/div/div/div[1]/div[1]/div[2]/section/main/div/article/form/div[5]/div/div")).click();
	}

	@When("I enter valid email or number phone and valid password")
		public void i_enter_valid_email_or_number_phone_and_valid_password() {
			driver.findElement(By.id("login_field")).sendKeys("feronikasimanjuntak");
		    driver.findElement(By.id("password")).sendKeys("4kuc4nt1kb4nget");
		}

}
