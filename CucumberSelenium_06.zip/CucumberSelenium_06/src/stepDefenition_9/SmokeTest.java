package stepDefenition_9;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SmokeTest {
	WebDriver driver;
	JavascriptExecutor js;

	@Given("^open chrome and start application$")
	public void open_chrome_and_start_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
		js = (JavascriptExecutor) driver;
		driver.manage().window().maximize();
		driver.get("https://www.instagram.com/");

	}

	@When("I enter valid username and valid password")
	public void i_enter_valid_username_and_valid_password() {
		driver.findElement(By.id("login_field")).sendKeys("elsasianturi2020@gmail.com");
	    driver.findElement(By.id("password")).sendKeys("antioil");
	}
	
	@Then("I can login successfully")
	public void i_can_login_successfully() {
		driver.findElement(By.name("commit")).click();
	}
	
	@Then("I click story$")
	public void i_click_story() throws InterruptedException {
	    driver.findElement(By.xpath("//*[@id=\"mount_0_0_TY\"]/div/div/div[2]/div/div/div/div[1]/div[1]/div[2]/section/main/div[1]/section/div/div[2]/div/div/div/div/ul/li[4]/div/button/div[1]")).click();
		Thread.sleep(1000);
	}
}
