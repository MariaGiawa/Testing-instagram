package runner;

import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@Cucumber.Options(features="Feature_4", glue="stepDefenition_4") // Folder penyimpanan feature file

public class TestRunner_4 {

}
