package runner;
import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@Cucumber.Options(features="Feature_6", glue="stepDefenition_6") // Folder penyimpanan feature file

public class TestRunner_6 {

}
