package runner;
import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@Cucumber.Options(features="Feature_7", glue="stepDefenition_7") // Folder penyimpanan feature file

public class TestRunner_7 {

}
