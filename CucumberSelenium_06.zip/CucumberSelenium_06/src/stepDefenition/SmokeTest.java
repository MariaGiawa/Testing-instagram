package stepDefenition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SmokeTest {
	WebDriver driver;

	@Given("^open chrome and start application$")
	public void open_chrome_and_start_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.instagram.com/");
	}

	@When("^I enter valid username and valid password$")
	public void I_enter_valid_username_and_valid_password() throws Throwable {
		driver.findElement(By.id("loginform-username")).sendKeys("elsadaysianturi2020@gmai.com");
		driver.findElement(By.id("loginform-password")).sendKeys("antioil");
	}

	@Then("^I can login succesfully$")
	public void I_can_login_succesfully() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"loginForm\"]/div/div[1]/div/label")).click();
	}

}
